import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { renderToPdf, getEngineStatus, RenderPdfOptions } from './server/pdfEngine.ts';

dotenv.config();

const app = express();
const PORT = 3000;

// Enable CORS for all cross-origin requests
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Api-Key', 'Accept'],
}));

// Generous payload limits for rich HTML with embedded base64 images and SVGs
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.text({ type: ['text/html', 'text/plain'], limit: '50mb' }));

// Optional API Key protection middleware
function checkApiKey(req: Request, res: Response, next: NextFunction) {
  const expectedKey = process.env.API_SECRET_KEY;
  if (!expectedKey || expectedKey.trim() === '') {
    return next();
  }

  const authHeader = req.headers['authorization'];
  const xApiKey = req.headers['x-api-key'];
  const queryKey = req.query['api_key'] || req.query['key'];

  const bearerToken = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : null;
  const providedKey = bearerToken || xApiKey || queryKey;

  if (providedKey === expectedKey) {
    return next();
  }

  return res.status(401).json({
    error: 'Unauthorized: Invalid or missing API key',
    hint: 'Pass your key in the Authorization header ("Bearer YOUR_KEY"), "X-Api-Key" header, or "?api_key=" query param.',
  });
}

// Health & Engine Status API
app.get('/api/status', async (req: Request, res: Response) => {
  try {
    const status = await getEngineStatus();
    res.json({
      ...status,
      appUrl: process.env.APP_URL || `http://localhost:${PORT}`,
      authConfigured: Boolean(process.env.API_SECRET_KEY && process.env.API_SECRET_KEY.trim() !== ''),
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Helper to extract render options from different request formats
function parseRenderPayload(req: Request): { options: RenderPdfOptions; filename: string; download: boolean } {
  let html = '';
  let url = '';
  let filename = 'document.pdf';
  let format = 'A4';
  let landscape = false;
  let printBackground = true;
  let scale = 1;
  let delay = 0;
  let download = false;
  let margin: RenderPdfOptions['margin'] = undefined;
  let displayHeaderFooter = false;
  let headerTemplate = '';
  let footerTemplate = '';

  // Check if raw text/html was sent
  if (typeof req.body === 'string' && req.body.trim().startsWith('<')) {
    html = req.body;
  } else if (req.body && typeof req.body === 'object') {
    html = req.body.html || '';
    url = req.body.url || '';
    filename = req.body.filename || filename;
    format = req.body.format || format;
    landscape = Boolean(req.body.landscape);
    printBackground = req.body.printBackground !== false && req.body.printBackground !== 'false' && req.body.printBackground !== 0 && req.body.printBackground !== '0';
    scale = Number(req.body.scale) || 1;
    delay = Number(req.body.delay) || 0;
    download = req.body.download === true || req.body.download === 'true' || req.body.download === 1 || req.body.download === '1';
    margin = req.body.margin;
    displayHeaderFooter = Boolean(req.body.displayHeaderFooter);
    headerTemplate = req.body.headerTemplate || '';
    footerTemplate = req.body.footerTemplate || '';
  }

  // Also check query parameters as fallback / overrides
  if (!html && req.query.html && typeof req.query.html === 'string') {
    html = req.query.html;
  }
  if (!url && req.query.url && typeof req.query.url === 'string') {
    url = req.query.url;
  }
  if (req.query.filename && typeof req.query.filename === 'string') {
    filename = req.query.filename;
  }
  if (req.query.format && typeof req.query.format === 'string') {
    format = req.query.format;
  }
  if (req.query.download !== undefined) {
    download = req.query.download === '1' || req.query.download === 'true';
  }
  if (req.query.landscape !== undefined) {
    landscape = req.query.landscape === '1' || req.query.landscape === 'true';
  }

  if (!filename.toLowerCase().endsWith('.pdf')) {
    filename += '.pdf';
  }

  return {
    options: {
      html,
      url,
      format: format as any,
      landscape,
      printBackground,
      scale,
      delay,
      margin,
      displayHeaderFooter,
      headerTemplate,
      footerTemplate,
    },
    filename,
    download,
  };
}

// Primary PDF Render Endpoint (Directly streams application/pdf binary)
app.post('/api/render', checkApiKey, async (req: Request, res: Response) => {
  const startTime = Date.now();
  try {
    const { options, filename, download } = parseRenderPayload(req);

    if (!options.html && !options.url) {
      return res.status(400).json({
        error: 'Missing required field: "html" or "url"',
        exampleJson: {
          html: '<h1>Invoice #1001</h1><p>Customer: Rahul Sharma</p>',
          filename: 'invoice-1001.pdf',
          format: 'A4',
          download: false,
        },
      });
    }

    const pdfBuffer = await renderToPdf(options);
    const duration = Date.now() - startTime;

    // Set response headers for PDF streaming
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `${download ? 'attachment' : 'inline'}; filename="${encodeURIComponent(filename)}"`
    );
    res.setHeader('Content-Length', pdfBuffer.length);
    res.setHeader('X-Render-Time-Ms', duration.toString());
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');

    return res.end(pdfBuffer);
  } catch (err: any) {
    console.error('PDF Render Error:', err);
    return res.status(500).json({
      error: 'PDF generation failed',
      message: err.message,
    });
  }
});

// GET /api/render - allows quick test from browser or direct URL link
app.get('/api/render', checkApiKey, async (req: Request, res: Response) => {
  const startTime = Date.now();
  try {
    const { options, filename, download } = parseRenderPayload(req);

    if (!options.html && !options.url) {
      return res.status(400).send(`
        <html>
          <body style="font-family:sans-serif;padding:40px;background:#090d16;color:#e2e8f0;">
            <h2 style="color:#38bdf8;">Chromium PDF API Endpoint</h2>
            <p>To render via GET, pass <code>?url=https://example.com</code> or use <code>POST /api/render</code> with your HTML quotation.</p>
            <p><a href="/" style="color:#38bdf8;">Go to Interactive Web Tester & PHP Code Generator &rarr;</a></p>
          </body>
        </html>
      `);
    }

    const pdfBuffer = await renderToPdf(options);
    const duration = Date.now() - startTime;

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `${download ? 'attachment' : 'inline'}; filename="${encodeURIComponent(filename)}"`
    );
    res.setHeader('Content-Length', pdfBuffer.length);
    res.setHeader('X-Render-Time-Ms', duration.toString());
    return res.end(pdfBuffer);
  } catch (err: any) {
    return res.status(500).json({ error: 'Render error', message: err.message });
  }
});

// POST /api/preview - Returns JSON with Base64 for the interactive web UI previewer
app.post('/api/preview', async (req: Request, res: Response) => {
  const startTime = Date.now();
  try {
    const { options } = parseRenderPayload(req);

    if (!options.html && !options.url) {
      return res.status(400).json({ error: 'No HTML or URL provided for preview' });
    }

    const pdfBuffer = await renderToPdf(options);
    const duration = Date.now() - startTime;

    return res.json({
      success: true,
      dataUrl: `data:application/pdf;base64,${pdfBuffer.toString('base64')}`,
      sizeBytes: pdfBuffer.length,
      durationMs: duration,
    });
  } catch (err: any) {
    console.error('Preview error:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

async function startServer() {
  // Integrate Vite for development or serve built assets in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Chromium PDF Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
