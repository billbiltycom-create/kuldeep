import puppeteer, { Browser, PaperFormat, PDFOptions } from 'puppeteer';

let browserInstance: Browser | null = null;
let isLaunching = false;
let launchPromise: Promise<Browser> | null = null;

const LAUNCH_ARGS = [
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-dev-shm-usage',
  '--disable-gpu',
  '--no-first-run',
  '--no-zygote',
  '--disable-extensions',
  '--font-render-hinting=medium',
  '--enable-font-antialiasing',
];

export async function getBrowser(): Promise<Browser> {
  if (browserInstance && browserInstance.connected) {
    return browserInstance;
  }

  if (isLaunching && launchPromise) {
    return launchPromise;
  }

  isLaunching = true;
  launchPromise = (async () => {
    try {
      if (browserInstance) {
        try {
          await browserInstance.close();
        } catch {
          // ignore close errors
        }
      }

      const browser = await puppeteer.launch({
        headless: true,
        args: LAUNCH_ARGS,
        timeout: 30000,
      });

      browserInstance = browser;
      browser.on('disconnected', () => {
        browserInstance = null;
      });

      return browser;
    } finally {
      isLaunching = false;
      launchPromise = null;
    }
  })();

  return launchPromise;
}

export interface RenderPdfOptions {
  html?: string;
  url?: string;
  format?: PaperFormat;
  landscape?: boolean;
  printBackground?: boolean;
  scale?: number;
  margin?: {
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
  };
  delay?: number;
  baseUrl?: string;
  displayHeaderFooter?: boolean;
  headerTemplate?: string;
  footerTemplate?: string;
  preferCSSPageSize?: boolean;
}

export async function renderToPdf(options: RenderPdfOptions): Promise<Buffer> {
  const browser = await getBrowser();
  const page = await browser.newPage();

  try {
    // Set a high-res viewport for desktop CSS rendering
    await page.setViewport({
      width: 1200,
      height: 1600,
      deviceScaleFactor: 2,
    });

    if (options.url) {
      await page.goto(options.url, {
        waitUntil: ['load', 'networkidle0'],
        timeout: 35000,
      });
    } else {
      let htmlContent = options.html || '<!DOCTYPE html><html><body><p>Empty Document</p></body></html>';
      if (options.baseUrl && !htmlContent.includes('<base ')) {
        if (htmlContent.includes('<head>')) {
          htmlContent = htmlContent.replace('<head>', `<head><base href="${options.baseUrl}">`);
        } else if (htmlContent.includes('<html>')) {
          htmlContent = htmlContent.replace('<html>', `<html><head><base href="${options.baseUrl}"></head>`);
        } else {
          htmlContent = `<base href="${options.baseUrl}">` + htmlContent;
        }
      }

      await page.setContent(htmlContent, {
        waitUntil: ['load', 'domcontentloaded'],
        timeout: 35000,
      });
    }

    // Wait for web fonts (Google Fonts, custom @font-face) to finish loading
    try {
      await page.evaluateHandle('document.fonts.ready');
    } catch {
      // ignore font loading error fallback
    }

    // If a custom render delay was specified (e.g. for dynamic charts or heavy JS)
    if (options.delay && options.delay > 0) {
      const waitTime = Math.min(Math.max(options.delay, 100), 10000);
      await new Promise((resolve) => setTimeout(resolve, waitTime));
    }

    // Prepare PDF options
    const pdfConfig: PDFOptions = {
      format: (options.format || 'A4') as PaperFormat,
      landscape: Boolean(options.landscape),
      printBackground: options.printBackground !== false,
      preferCSSPageSize: options.preferCSSPageSize ?? true,
      scale: options.scale && options.scale >= 0.1 && options.scale <= 2 ? options.scale : 1,
      margin: options.margin || {
        top: '0mm',
        right: '0mm',
        bottom: '0mm',
        left: '0mm',
      },
      displayHeaderFooter: Boolean(options.displayHeaderFooter),
      headerTemplate: options.headerTemplate || '',
      footerTemplate: options.footerTemplate || '',
    };

    const pdfBuffer = await page.pdf(pdfConfig);
    return Buffer.from(pdfBuffer);
  } finally {
    try {
      await page.close();
    } catch {
      // ignore page close error
    }
  }
}

export async function getEngineStatus() {
  let browserConnected = false;
  let browserVersion = 'Not initialized';
  let pagesCount = 0;

  try {
    if (browserInstance && browserInstance.connected) {
      browserConnected = true;
      browserVersion = await browserInstance.version();
      const pages = await browserInstance.pages();
      pagesCount = pages.length;
    } else {
      // Quick probe
      const browser = await getBrowser();
      browserConnected = true;
      browserVersion = await browser.version();
      const pages = await browser.pages();
      pagesCount = pages.length;
    }
  } catch (err: any) {
    browserVersion = `Launch error: ${err.message}`;
  }

  const memory = process.memoryUsage();

  return {
    status: browserConnected ? 'ready' : 'initializing',
    engine: 'Chromium Headless (Puppeteer)',
    browserVersion,
    browserConnected,
    activePages: pagesCount,
    memoryRssMb: Math.round(memory.rss / (1024 * 1024)),
    memoryHeapUsedMb: Math.round(memory.heapUsed / (1024 * 1024)),
    nodeVersion: process.version,
    platform: `${process.platform} (${process.arch})`,
    uptimeSeconds: Math.round(process.uptime()),
    timestamp: new Date().toISOString(),
  };
}
