import React, { useState } from 'react';
import { FileText, Copy, Check, Terminal, Code2, Server, ExternalLink, Activity } from 'lucide-react';
import { EngineStatus } from '../types';

interface HeaderProps {
  activeTab: 'studio' | 'php' | 'docs' | 'status';
  setActiveTab: (tab: 'studio' | 'php' | 'docs' | 'status') => void;
  status: EngineStatus | null;
  apiUrl: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  status,
  apiUrl,
}) => {
  const [copied, setCopied] = useState(false);

  const copyApiUrl = () => {
    navigator.clipboard.writeText(`${apiUrl}/api/render`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between py-3 gap-3">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-sky-400 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
                  BillBilty <span className="text-cyan-400">PDF Microservice</span>
                </h1>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800/60">
                  Chromium Headless
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Core PHP Shared Hosting के लिए 100% Pixel-Perfect HTML to PDF Engine
              </p>
            </div>
          </div>

          {/* Live Endpoint Pill with Copy Button */}
          <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-800 rounded-lg p-1.5 px-3 self-start md:self-auto">
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <span className="text-slate-500 font-mono">POST</span>
              <span className="font-mono text-cyan-400 truncate max-w-[200px] sm:max-w-[280px]">
                {apiUrl ? `${apiUrl}/api/render` : '/api/render'}
              </span>
            </div>
            <button
              onClick={copyApiUrl}
              className="inline-flex items-center gap-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-2 py-1 rounded transition-colors"
              title="Copy Live API Endpoint for your PHP code"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-medium">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy URL</span>
                </>
              )}
            </button>
          </div>

          {/* Engine Status indicator */}
          <div className="hidden lg:flex items-center gap-2 text-xs">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-slate-300 font-medium">
              {status?.browserConnected ? 'Chromium Engine Ready' : 'Initializing...'}
            </span>
            {status?.memoryRssMb ? (
              <span className="text-slate-500 text-[11px]">({status.memoryRssMb} MB)</span>
            ) : null}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-1 border-t border-slate-800/80 pt-2 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('studio')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'studio'
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>लाइव स्टूडियो एवं प्रिव्यू (Live Studio)</span>
          </button>

          <button
            onClick={() => setActiveTab('php')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'php'
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>पीएचपी इंटीग्रेशन कोड (PHP Integration)</span>
            <span className="bg-amber-500/20 text-amber-300 text-[10px] font-bold px-1.5 py-0.5 rounded">
              DomPDF / mPDF विकल्प
            </span>
          </button>

          <button
            onClick={() => setActiveTab('docs')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'docs'
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>एपीआई गाइड (API Docs & cURL)</span>
          </button>

          <button
            onClick={() => setActiveTab('status')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'status'
                ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>इंजन स्टेटस (Engine Health)</span>
          </button>
        </div>
      </div>
    </header>
  );
};
