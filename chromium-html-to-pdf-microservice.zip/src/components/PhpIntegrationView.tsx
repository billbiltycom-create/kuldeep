import React, { useState } from 'react';
import { Copy, Check, Terminal, FileCode, ArrowRight, ShieldCheck, Zap, Layers, HelpCircle } from 'lucide-react';

interface PhpIntegrationViewProps {
  apiUrl: string;
}

export const PhpIntegrationView: React.FC<PhpIntegrationViewProps> = ({ apiUrl }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'replacement' | 'curl' | 'form' | 'save'>('replacement');

  const liveEndpoint = `${apiUrl || window.location.origin}/api/render`;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2500);
  };

  // Code 1: Drop-in replacement for Dompdf / mpdf
  const dropinCode = `<?php
/**
 * BillBilty Chromium PDF Helper Class
 * Drop-in replacement for Dompdf / mPDF for Core PHP on Shared Hosting.
 * No Chromium installation required on your shared hosting server!
 */
class BillBiltyPdf {
    private $html = '';
    private $apiUrl = '${liveEndpoint}';
    private $options = [
        'format' => 'A4',
        'landscape' => false,
        'printBackground' => true,
        'scale' => 1
    ];

    public function __construct($apiUrl = null) {
        if ($apiUrl) {
            $this->apiUrl = $apiUrl;
        }
    }

    // DomPDF compatible method
    public function loadHtml($html) {
        $this->html = $html;
        return $this;
    }

    public function setPaper($format = 'A4', $orientation = 'portrait') {
        $this->options['format'] = $format;
        $this->options['landscape'] = ($orientation === 'landscape');
        return $this;
    }

    public function render() {
        // Ready for output/stream
        return $this;
    }

    /**
     * Streams the PDF directly to browser (Open in browser or force download)
     * @param string $filename Name of the output PDF
     * @param array $options ['Attachment' => 0 or 1]
     */
    public function stream($filename = 'document.pdf', $options = ['Attachment' => 0]) {
        $pdfContent = $this->output();
        
        $isAttachment = isset($options['Attachment']) && $options['Attachment'] == 1;
        $disposition = $isAttachment ? 'attachment' : 'inline';

        if (!headers_sent()) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: ' . $disposition . '; filename="' . $filename . '"');
            header('Content-Length: ' . strlen($pdfContent));
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
        }

        echo $pdfContent;
        exit;
    }

    /**
     * Returns raw binary PDF bytes (useful for saving to disk or attaching to email)
     */
    public function output() {
        $payload = json_encode([
            'html' => $this->html,
            'format' => $this->options['format'],
            'landscape' => $this->options['landscape'],
            'printBackground' => $this->options['printBackground'],
            'scale' => $this->options['scale'],
            'download' => false
        ]);

        $ch = curl_init($this->apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/pdf'
        ]);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($httpCode !== 200 || !$response) {
            throw new Exception("PDF Generation Error (HTTP $httpCode): " . ($error ?: $response));
        }

        return $response;
    }
}
?>`;

  // Code 2: How to use the drop-in class in existing quotation file
  const usageCode = `<?php
// Step 1: Include the helper class
require_once 'BillBiltyPdf.php';

// Step 2: Fetch quotation data from your database (Just like you currently do)
$quotation_id = $_GET['id'];
// $quoteData = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM quotations WHERE id='$quotation_id'"));

// Step 3: Get your HTML template
ob_start();
include 'templates/quotation_template.php'; // Your full HTML with CSS Grid, Flexbox, Tailwind, etc.
$html = ob_get_clean();

// Step 4: Render & Stream PDF (Exact same as DomPDF!)
$pdf = new BillBiltyPdf();
$pdf->loadHtml($html);
$pdf->setPaper('A4', 'portrait');
$pdf->render();

// Opens PDF directly in browser with 100% exact modern CSS:
$pdf->stream("Quotation_#$quotation_id.pdf", ["Attachment" => 0]);
?>`;

  // Code 3: Quick standalone cURL function
  const curlFunctionCode = `<?php
function generateChromiumPdf($html, $filename = 'invoice.pdf', $forceDownload = false) {
    $apiUrl = '${liveEndpoint}';

    $postData = json_encode([
        'html' => $html,
        'filename' => $filename,
        'format' => 'A4',
        'printBackground' => true,
        'download' => $forceDownload
    ]);

    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $pdfData = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200) {
        header('Content-Type: application/pdf');
        header('Content-Disposition: ' . ($forceDownload ? 'attachment' : 'inline') . '; filename="' . $filename . '"');
        echo $pdfData;
        exit;
    } else {
        die('PDF Generation Error: ' . $pdfData);
    }
}
?>`;

  // Code 4: HTML Form POST
  const formPostCode = `<!-- Direct HTML Form in your PHP Billing Portal (Opens PDF in New Tab on Submit) -->
<form action="${liveEndpoint}" method="POST" target="_blank">
  <!-- Pass your quotation HTML into this hidden textarea or input -->
  <input type="hidden" name="filename" value="Quotation_1001.pdf">
  <input type="hidden" name="format" value="A4">
  <input type="hidden" name="printBackground" value="true">
  <input type="hidden" name="download" value="false">
  
  <textarea name="html" style="display:none;">
    <!-- Paste your dynamic PHP quotation HTML here -->
    <!DOCTYPE html>
    <html>
      <head><style>/* Your Modern CSS Grid & Flexbox */</style></head>
      <body><h1>Quotation #1001</h1></body>
    </html>
  </textarea>

  <button type="submit" class="btn btn-primary">
    📄 View Quotation PDF (Chromium)
  </button>
</form>`;

  // Code 5: Save to disk & email
  const saveDiskCode = `<?php
require_once 'BillBiltyPdf.php';

$pdf = new BillBiltyPdf();
$pdf->loadHtml($html);

// Get the raw PDF binary bytes
$pdfBytes = $pdf->output();

// 1. Save to your shared hosting folder:
$savePath = __DIR__ . '/invoices/Quotation_' . $quote_id . '.pdf';
file_put_contents($savePath, $pdfBytes);

// 2. Attach to PHPMailer or send to WhatsApp:
// $mail->addAttachment($savePath);
// $mail->send();

echo "PDF saved successfully at: " . $savePath;
?>`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Intro Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/60 rounded-2xl p-6 sm:p-8 mb-8 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-semibold mb-3">
              <Zap className="w-3.5 h-3.5" /> Shared Hosting Solution (शेयर्ड होस्टिंग के लिए समाधान)
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              DomPDF / mPDF को 1 मिनट में बदलें
            </h2>
            <p className="mt-2 text-slate-300 text-sm sm:text-base leading-relaxed">
              आपकी शेयर्ड होस्टिंग पर कोई भी Node.js या Chromium इंस्टॉल करने की ज़रूरत नहीं है। आपकी PHP स्क्रिप्ट केवल एक साधारण cURL कॉल के ज़रिए इस लाइव सिस्टम को HTML भेजेगी, और यह सिस्टम <strong>Real Chromium</strong> के ज़रिए 100% पिक्सेल-परफेक्ट PDF तुरंत रेंडर करके आपको वापस देगा।
            </p>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 min-w-[280px]">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              आपके सिस्टम का लाइव लिंक (API URL):
            </div>
            <div className="font-mono text-xs text-cyan-300 bg-slate-900 p-2.5 rounded-lg border border-slate-700/80 break-all select-all">
              {liveEndpoint}
            </div>
            <button
              onClick={() => copyToClipboard(liveEndpoint, 99)}
              className="mt-3 w-full inline-flex items-center justify-center gap-1.5 text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white py-2 rounded-lg transition-colors"
            >
              {copiedIndex === 99 ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>लिंक कॉपी हो गया!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>कॉपी API लिंक</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Sub tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-800 pb-4 mb-6">
        <button
          onClick={() => setActiveSubTab('replacement')}
          className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
            activeSubTab === 'replacement'
              ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          1. Drop-in Class (BillBiltyPdf.php)
        </button>
        <button
          onClick={() => setActiveSubTab('curl')}
          className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
            activeSubTab === 'curl'
              ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          2. Simple cURL Function
        </button>
        <button
          onClick={() => setActiveSubTab('form')}
          className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
            activeSubTab === 'form'
              ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          3. Direct HTML Form POST
        </button>
        <button
          onClick={() => setActiveSubTab('save')}
          className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
            activeSubTab === 'save'
              ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          4. Save to Disk & Email
        </button>
      </div>

      {/* Content for active sub tab */}
      {activeSubTab === 'replacement' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileCode className="w-5 h-5 text-cyan-400" />
                  चरण 1: अपने प्रोजेक्ट में `BillBiltyPdf.php` फ़ाइल बनाएं
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  इस फ़ाइल को अपने PHP प्रोजेक्ट के रूट या include फ़ोल्डर में सेव करें। यह DomPDF जैसी ही <code className="text-cyan-300">loadHtml()</code> और <code className="text-cyan-300">stream()</code> मेथड्स प्रदान करता है।
                </p>
              </div>
              <button
                onClick={() => copyToClipboard(dropinCode, 1)}
                className="inline-flex items-center gap-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-cyan-400 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
              >
                {copiedIndex === 1 ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedIndex === 1 ? 'Copied!' : 'Copy Code'}</span>
              </button>
            </div>
            <pre className="bg-slate-950 p-4 rounded-lg overflow-x-auto text-xs font-mono text-slate-200 border border-slate-800/80 max-h-[380px] scrollbar-thin">
              {dropinCode}
            </pre>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-emerald-400" />
                  चरण 2: अपने मौजूदा Quotation / Invoice फ़ाइल में DomPDF की जगह इसका यूज़ करें
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  आपको अपना HTML या SQL कोड बदलने की ज़रूरत नहीं है! बस <code className="text-emerald-400">new Dompdf()</code> की जगह <code className="text-emerald-400">new BillBiltyPdf()</code> लिख दीजिए।
                </p>
              </div>
              <button
                onClick={() => copyToClipboard(usageCode, 2)}
                className="inline-flex items-center gap-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-cyan-400 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
              >
                {copiedIndex === 2 ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedIndex === 2 ? 'Copied!' : 'Copy Code'}</span>
              </button>
            </div>
            <pre className="bg-slate-950 p-4 rounded-lg overflow-x-auto text-xs font-mono text-slate-200 border border-slate-800/80 max-h-[320px] scrollbar-thin">
              {usageCode}
            </pre>
          </div>
        </div>
      )}

      {activeSubTab === 'curl' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Terminal className="w-5 h-5 text-cyan-400" />
                सिंगल cURL फ़ंक्शन (10 Lines of PHP)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                अगर आप कोई क्लास नहीं बनाना चाहते, तो सीधे इस फ़ंक्शन को अपने <code className="text-cyan-300">functions.php</code> में डाल दें।
              </p>
            </div>
            <button
              onClick={() => copyToClipboard(curlFunctionCode, 3)}
              className="inline-flex items-center gap-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-cyan-400 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
            >
              {copiedIndex === 3 ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedIndex === 3 ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>
          <pre className="bg-slate-950 p-4 rounded-lg overflow-x-auto text-xs font-mono text-slate-200 border border-slate-800/80 max-h-[360px] scrollbar-thin">
            {curlFunctionCode}
          </pre>
        </div>
      )}

      {activeSubTab === 'form' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-amber-400" />
                HTML Form Submit से डायरेक्ट PDF ओपन करें
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                अगर आप बिना cURL के सीधे ब्राउज़र से PDF नए टैब में खोलना चाहते हैं, तो एक साधारण HTML फॉर्म सबमिट कर सकते हैं:
              </p>
            </div>
            <button
              onClick={() => copyToClipboard(formPostCode, 4)}
              className="inline-flex items-center gap-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-cyan-400 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
            >
              {copiedIndex === 4 ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedIndex === 4 ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>
          <pre className="bg-slate-950 p-4 rounded-lg overflow-x-auto text-xs font-mono text-slate-200 border border-slate-800/80 max-h-[360px] scrollbar-thin">
            {formPostCode}
          </pre>
        </div>
      )}

      {activeSubTab === 'save' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-purple-400" />
                PDF को शेयर्ड होस्टिंग सर्वर पर सेव करें और ईमेल से भेजें
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                <code className="text-purple-300">$pdf-&gt;output()</code> से बाइनरी डेटा मिलता है जिसे आप <code className="text-purple-300">file_put_contents()</code> से सर्वर पर सेव कर सकते हैं:
              </p>
            </div>
            <button
              onClick={() => copyToClipboard(saveDiskCode, 5)}
              className="inline-flex items-center gap-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-cyan-400 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
            >
              {copiedIndex === 5 ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedIndex === 5 ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>
          <pre className="bg-slate-950 p-4 rounded-lg overflow-x-auto text-xs font-mono text-slate-200 border border-slate-800/80 max-h-[360px] scrollbar-thin">
            {saveDiskCode}
          </pre>
        </div>
      )}

      {/* Feature comparison table */}
      <div className="mt-10 bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h3 className="text-lg font-bold text-white mb-2">
          DomPDF / mPDF vs BillBilty Chromium Microservice तुलना
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          देखें कि क्यों आधुनिक CSS Grid, Flexbox और जटिल इनवॉइस डिजाइनों के लिए Chromium ही एकमात्र समाधान है:
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider bg-slate-950/60">
                <th className="py-3 px-4 font-semibold">फ़ीचर (Feature)</th>
                <th className="py-3 px-4 font-semibold text-rose-400">DomPDF / mPDF (पुरानी तकनीक)</th>
                <th className="py-3 px-4 font-semibold text-emerald-400">यह Chromium Microservice (Google Chrome Engine)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">CSS Grid Layout</td>
                <td className="py-3 px-4 text-rose-400">❌ पूरी तरह फेल (पेज बिगड़ जाता है)</td>
                <td className="py-3 px-4 text-emerald-400">✅ 100% परफेक्ट (Exact जैसा ब्राउज़र में दिखता है)</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Flexbox (justify, align, gap)</td>
                <td className="py-3 px-4 text-rose-400">❌ आंशिक या बिल्कुल काम नहीं करता</td>
                <td className="py-3 px-4 text-emerald-400">✅ 100% नेटिव क्रोमियम सपोर्ट</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Google Fonts & Custom Fonts</td>
                <td className="py-3 px-4 text-rose-400">❌ मुश्किल फॉन्ट इन्स्टॉलेशन, अक्सर फॉन्ट ब्रेक</td>
                <td className="py-3 px-4 text-emerald-400">✅ ऑटोमैटिक वेब फॉन्ट्स डाउनलोड और रेंडर</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Exact Margins & Padding</td>
                <td className="py-3 px-4 text-rose-400">⚠️ अक्सर 10-20px का अंतर आ जाता है</td>
                <td className="py-3 px-4 text-emerald-400">✅ 1% भी अंतर नहीं (0.1mm शुद्धता)</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">शेयर्ड होस्टिंग पर लोड</td>
                <td className="py-3 px-4 text-amber-400">⚠️ शेयर्ड होस्टिंग की CPU और RAM पर लोड पड़ता है</td>
                <td className="py-3 px-4 text-emerald-400">✅ 0% लोड! सारा रेंडरिंग Cloud Run पर होता है</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
