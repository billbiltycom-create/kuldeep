import React, { useState, useEffect } from 'react';
import {
  Play,
  Download,
  ExternalLink,
  RotateCw,
  FileText,
  Sliders,
  Sparkles,
  Check,
  Copy,
  Clock,
  Layers,
  FileCheck
} from 'lucide-react';
import { INVOICE_TEMPLATES } from '../templates/invoiceTemplates';
import { RenderPdfRequest } from '../types';

interface StudioViewProps {
  apiUrl: string;
}

export const StudioView: React.FC<StudioViewProps> = ({ apiUrl }) => {
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('gst-invoice');
  const [htmlContent, setHtmlContent] = useState<string>(INVOICE_TEMPLATES[0].html);
  const [filename, setFilename] = useState<string>('invoice-billbilty.pdf');
  const [format, setFormat] = useState<'A4' | 'Letter' | 'Legal' | 'A3' | 'A5'>('A4');
  const [landscape, setLandscape] = useState<boolean>(false);
  const [printBackground, setPrintBackground] = useState<boolean>(true);
  const [marginPreset, setMarginPreset] = useState<'0' | '5' | '10' | '15'>('0');

  // Preview state
  const [isRendering, setIsRendering] = useState<boolean>(false);
  const [pdfDataUrl, setPdfDataUrl] = useState<string | null>(null);
  const [renderMetrics, setRenderMetrics] = useState<{ durationMs: number; sizeBytes: number } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedHtml, setCopiedHtml] = useState<boolean>(false);

  // Switch template
  const handleTemplateChange = (templateId: string) => {
    setSelectedTemplateId(templateId);
    const tmpl = INVOICE_TEMPLATES.find((t) => t.id === templateId);
    if (tmpl) {
      setHtmlContent(tmpl.html);
      if (tmpl.id === 'gst-invoice') setFilename('tax-invoice-bb.pdf');
      else if (tmpl.id === 'quotation-modern') setFilename('official-quotation.pdf');
      else if (tmpl.id === 'transport-bilty') setFilename('transport-bilty-consignment.pdf');
      else setFilename('custom-invoice.pdf');
    }
  };

  // Perform rendering via backend POST /api/preview
  const handleRender = async () => {
    setIsRendering(true);
    setErrorMessage(null);

    const marginValue = `${marginPreset}mm`;
    const payload: RenderPdfRequest = {
      html: htmlContent,
      filename,
      format,
      landscape,
      printBackground,
      scale: 1,
      margin: {
        top: marginValue,
        right: marginValue,
        bottom: marginValue,
        left: marginValue,
      },
    };

    try {
      const response = await fetch('/api/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to render PDF');
      }

      setPdfDataUrl(data.dataUrl);
      setRenderMetrics({
        durationMs: data.durationMs,
        sizeBytes: data.sizeBytes,
      });
    } catch (err: any) {
      console.error('Render error:', err);
      setErrorMessage(err.message || 'Error communicating with Chromium server');
    } finally {
      setIsRendering(false);
    }
  };

  // Auto render initial template on first load
  useEffect(() => {
    handleRender();
  }, []);

  // Direct download handler
  const handleDownload = () => {
    if (!pdfDataUrl) return;
    const a = document.createElement('a');
    a.href = pdfDataUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Open PDF in new tab
  const handleOpenNewTab = () => {
    if (!pdfDataUrl) return;
    const newWindow = window.open();
    if (newWindow) {
      newWindow.document.write(
        `<iframe src="${pdfDataUrl}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`
      );
      newWindow.document.title = filename;
    }
  };

  const copyHtmlCode = () => {
    navigator.clipboard.writeText(htmlContent);
    setCopiedHtml(true);
    setTimeout(() => setCopiedHtml(false), 2000);
  };

  return (
    <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Banner: Quick Context */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            लाइव कोटेशन एवं इनवॉइस रेंडरर (Live Studio)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            नीचे दिए गए किसी भी टेम्पलेट को चुनें या अपना Core PHP HTML कोड पेस्ट करें और देखें कि क्रोमियम उसे 100% पिक्सेल-परफेक्ट कैसे रेंडर करता है।
          </p>
        </div>

        {/* Template Selector Pills */}
        <div className="flex flex-wrap items-center gap-1.5 self-start md:self-auto">
          {INVOICE_TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.id}
              onClick={() => handleTemplateChange(tmpl.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                selectedTemplateId === tmpl.id
                  ? 'bg-cyan-500 text-white shadow-sm shadow-cyan-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              {tmpl.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Dual Pane Studio */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Editor & Controls (5 cols) */}
        <div className="lg:col-span-6 xl:col-span-5 flex flex-col space-y-4">
          {/* Controls Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-300 border-b border-slate-800 pb-2">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-cyan-400" />
                रेंडरिंग सेटिंग्स (PDF Options)
              </span>
              <span className="text-[11px] text-slate-500 font-normal">DomPDF/mPDF से 10x तेज़</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              {/* Paper Format */}
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">पेज साइज:</label>
                <select
                  value={format}
                  onChange={(e) => setFormat(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="A4">A4 (Standard)</option>
                  <option value="Letter">US Letter</option>
                  <option value="Legal">Legal</option>
                  <option value="A3">A3 (Large)</option>
                  <option value="A5">A5 (Slip / Small)</option>
                </select>
              </div>

              {/* Orientation */}
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">ओरिएंटेशन:</label>
                <select
                  value={landscape ? 'landscape' : 'portrait'}
                  onChange={(e) => setLandscape(e.target.value === 'landscape')}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="portrait">Portrait (सीधा)</option>
                  <option value="landscape">Landscape (आड़ा)</option>
                </select>
              </div>

              {/* Margins */}
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">मार्जिन (Margin):</label>
                <select
                  value={marginPreset}
                  onChange={(e) => setMarginPreset(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="0">0mm (CSS Controlled)</option>
                  <option value="5">5mm (Compact)</option>
                  <option value="10">10mm (Standard)</option>
                  <option value="15">15mm (Wide)</option>
                </select>
              </div>

              {/* Background Graphics */}
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">बैकग्राउंड कलर्स:</label>
                <button
                  type="button"
                  onClick={() => setPrintBackground(!printBackground)}
                  className={`w-full px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-colors text-center ${
                    printBackground
                      ? 'bg-cyan-950/70 border-cyan-800 text-cyan-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  {printBackground ? '✓ Print Color' : 'No Colors'}
                </button>
              </div>
            </div>

            {/* Filename & Render Action */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-1">
              <div className="w-full sm:flex-1">
                <input
                  type="text"
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  placeholder="invoice.pdf"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <button
                onClick={handleRender}
                disabled={isRendering}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-400 hover:to-sky-400 text-white font-semibold text-xs shadow-lg shadow-cyan-500/25 transition-all disabled:opacity-50 whitespace-nowrap cursor-pointer"
              >
                {isRendering ? (
                  <>
                    <RotateCw className="w-4 h-4 animate-spin" />
                    <span>क्रोमियम रेंडर कर रहा है...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    <span>PDF रेंडर करें (Generate)</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* HTML Code Editor Area */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
            <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>HTML &amp; CSS Source Code (अपने PHP से जनरेटेड HTML)</span>
              </div>
              <button
                onClick={copyHtmlCode}
                className="text-xs text-slate-400 hover:text-white inline-flex items-center gap-1 transition-colors"
              >
                {copiedHtml ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedHtml ? 'Copied' : 'Copy HTML'}</span>
              </button>
            </div>

            <div className="relative">
              <textarea
                value={htmlContent}
                onChange={(e) => setHtmlContent(e.target.value)}
                rows={22}
                className="w-full bg-slate-950/90 text-slate-200 font-mono text-xs p-4 focus:outline-none resize-y leading-relaxed selection:bg-cyan-500 selection:text-white scrollbar-thin"
                spellCheck={false}
                placeholder="Paste your PHP generated HTML here..."
              />
            </div>
          </div>
        </div>

        {/* Right Column: Live Chromium PDF Viewer (7 cols) */}
        <div className="lg:col-span-6 xl:col-span-7 flex flex-col space-y-4">
          {/* Viewer Toolbar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold text-white">Chromium Print Output</span>
              </div>

              {renderMetrics && (
                <div className="hidden sm:flex items-center gap-2 text-slate-400 text-[11px] bg-slate-950 px-2.5 py-1 rounded-md border border-slate-800">
                  <span className="flex items-center gap-1 text-emerald-400">
                    <Clock className="w-3 h-3" /> {renderMetrics.durationMs}ms
                  </span>
                  <span>•</span>
                  <span>{(renderMetrics.sizeBytes / 1024).toFixed(1)} KB</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleOpenNewTab}
                disabled={!pdfDataUrl}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors disabled:opacity-40"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>नए टैब में खोलें</span>
              </button>

              <button
                onClick={handleDownload}
                disabled={!pdfDataUrl}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition-colors disabled:opacity-40 shadow-sm shadow-cyan-600/30"
              >
                <Download className="w-3.5 h-3.5" />
                <span>डाउनलोड PDF</span>
              </button>
            </div>
          </div>

          {/* PDF Preview Frame or Loading/Error State */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden min-h-[640px] flex flex-col justify-center relative shadow-2xl">
            {isRendering && (
              <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm z-20 flex flex-col items-center justify-center p-6 text-center">
                <div className="w-12 h-12 rounded-full border-3 border-cyan-500/20 border-t-cyan-400 animate-spin mb-4"></div>
                <h4 className="text-base font-bold text-white">Chromium इंजन PDF रेंडर कर रहा है...</h4>
                <p className="text-xs text-slate-400 max-w-sm mt-1">
                  CSS Grid, Flexbox, Web Fonts और मार्जिन को बिना किसी 1% भी अंतर के प्रोसेस किया जा रहा है।
                </p>
              </div>
            )}

            {errorMessage ? (
              <div className="p-8 text-center">
                <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-3">
                  ⚠️
                </div>
                <h4 className="text-base font-bold text-rose-300">रेंडरिंग में त्रुटि (Error)</h4>
                <p className="text-xs text-rose-400/80 mt-1 max-w-md mx-auto">{errorMessage}</p>
                <button
                  onClick={handleRender}
                  className="mt-4 px-4 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-semibold hover:bg-rose-500"
                >
                  दोबारा प्रयास करें
                </button>
              </div>
            ) : pdfDataUrl ? (
              <iframe
                src={`${pdfDataUrl}#toolbar=0&navpanes=0&scrollbar=1`}
                className="w-full h-[680px] bg-slate-800 border-none"
                title="Chromium Rendered PDF Preview"
              />
            ) : (
              <div className="p-8 text-center text-slate-500">
                <FileText className="w-12 h-12 mx-auto mb-2 opacity-40" />
                <p className="text-sm">रेंडर करने के लिए "PDF रेंडर करें" बटन दबाएं</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
