import React, { useState } from 'react';
import { Activity, Server, RefreshCw, Cpu, HardDrive, CheckCircle2, Clock, Globe } from 'lucide-react';
import { EngineStatus } from '../types';

interface EngineStatusViewProps {
  status: EngineStatus | null;
  onRefresh: () => void;
  isLoading: boolean;
}

export const EngineStatusView: React.FC<EngineStatusViewProps> = ({
  status,
  onRefresh,
  isLoading,
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Activity className="w-6 h-6 text-emerald-400" />
            क्रोमियम इंजन स्टेटस एवं हेल्थ (Engine Health)
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Google Chrome (Headless) रेंडरिंग कंटेनर और मेमोरी स्थिति।
          </p>
        </div>
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors disabled:opacity-50 self-start"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>रिफ्रेश स्टेटस</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        {/* Card 1: Engine Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider">इंजन स्थिति</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>{status?.status === 'ready' ? 'सक्रिय (Online)' : 'प्रारंभ हो रहा है'}</span>
          </div>
          <p className="text-xs text-slate-400 mt-2 truncate">
            {status?.browserVersion || 'Google Chrome for Testing'}
          </p>
        </div>

        {/* Card 2: Memory */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider">RAM उपयोग</span>
            <HardDrive className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-white">
            {status?.memoryRssMb ? `${status.memoryRssMb} MB` : 'गणना हो रही है...'}
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Heap: {status?.memoryHeapUsedMb || 0} MB
          </p>
        </div>

        {/* Card 3: Uptime */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider">अपटाइम (Uptime)</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold text-white">
            {status?.uptimeSeconds ? `${Math.floor(status.uptimeSeconds / 60)} min ${status.uptimeSeconds % 60} sec` : '0 min'}
          </div>
          <p className="text-xs text-slate-400 mt-2">
            सक्रिय ब्राउज़र पेज: {status?.activePages ?? 0}
          </p>
        </div>

        {/* Card 4: Platform */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider">प्लेटफ़ॉर्म</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl font-bold text-white truncate">
            {status?.platform || 'Linux x64'}
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Node.js {status?.nodeVersion || 'v22'}
          </p>
        </div>
      </div>

      {/* Cloud Run Architecture Details */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <Server className="w-5 h-5 text-cyan-400" />
          क्लाउड रन (Cloud Run) माइक्रो-सर्विस आर्किटेक्चर
        </h3>
        <p className="text-sm text-slate-300 leading-relaxed mb-4">
          यह सिस्टम Google Cloud Run के सुरक्षित कंटेनर पर चलता है। जब आप अपनी शेयर्ड होस्टिंग से कोई भी Quotation या Invoice HTML भेजते हैं, तो यह कंटेनर में मौजूद वास्तविक Chromium ब्राउज़र के ज़रिए उसे उच्च रेजोल्यूशन (deviceScaleFactor: 2) में प्रिंट-रेंडर करता है और तुरंत PDF स्ट्रीम करता है।
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <div className="font-semibold text-cyan-300 mb-1">🚀 ज़ीरो सर्वर लोड</div>
            <div className="text-slate-400">आपकी cPanel / शेयर्ड होस्टिंग पर कोई भी भारी प्रोसेसिंग या मेमोरी लोड नहीं पड़ेगा।</div>
          </div>
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <div className="font-semibold text-emerald-300 mb-1">🎯 100% CSS3 सपोर्ट</div>
            <div className="text-slate-400">Flexbox, CSS Grid, Web Fonts, SVG और जटिल टेबल्स बिना किसी बग के रेंडर होते हैं।</div>
          </div>
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <div className="font-semibold text-amber-300 mb-1">⚡ इंस्टेंट रिस्पॉन्स</div>
            <div className="text-slate-400">ब्राउज़र इंस्टेंस हमेशा वार्म रहता है जिससे प्रत्येक PDF मात्र 200-400ms में तैयार हो जाती है।</div>
          </div>
        </div>
      </div>
    </div>
  );
};
