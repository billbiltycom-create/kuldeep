import React, { useState } from 'react';
import { Terminal, Copy, Check, Shield, FileText, ArrowRight, Globe } from 'lucide-react';

interface ApiDocsViewProps {
  apiUrl: string;
}

export const ApiDocsView: React.FC<ApiDocsViewProps> = ({ apiUrl }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const endpoint = `${apiUrl || window.location.origin}/api/render`;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const curlJson = `curl -X POST "${endpoint}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "html": "<html><body><h1 style=\\"color:#0284c7;\\">Hello Invoice</h1><p>Customer: Vikram</p></body></html>",
    "filename": "quotation-test.pdf",
    "format": "A4",
    "printBackground": true,
    "download": false
  }' \\
  --output test-quotation.pdf`;

  const curlRaw = `curl -X POST "${endpoint}" \\
  -H "Content-Type: text/html" \\
  --data-binary "@my_invoice.html" \\
  --output invoice_rendered.pdf`;

  const curlUrl = `curl -X GET "${endpoint}?url=https://news.ycombinator.com&filename=news.pdf" \\
  --output webpage.pdf`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Terminal className="w-6 h-6 text-cyan-400" />
          HTTP API Documentation &amp; Endpoints
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          किसी भी प्रोग्रामिंग भाषा (PHP, Python, Node.js, cURL, C#, Go) से तुरंत कॉल करने के लिए REST API विवरण।
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Endpoints & cURL */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main Endpoint Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold border border-emerald-500/30">
                  POST
                </span>
                <span className="font-mono text-sm font-semibold text-white">/api/render</span>
              </div>
              <span className="text-xs text-slate-400">Streams `application/pdf` binary</span>
            </div>

            <p className="text-xs text-slate-300 mb-4">
              यह प्राथमिक एंडपॉइंट है। जब आप इसमें HTML या URL भेजते हैं, तो यह सीधे Chromium के ज़रिए रेंडर करके शुद्ध बाइनरी PDF वापस देता है।
            </p>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-slate-300">1. JSON Payload Request (अनुशंसित तरीका)</span>
                  <button
                    onClick={() => copyToClipboard(curlJson, 1)}
                    className="text-xs text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1"
                  >
                    {copiedIndex === 1 ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedIndex === 1 ? 'Copied' : 'Copy cURL'}</span>
                  </button>
                </div>
                <pre className="bg-slate-950 p-3.5 rounded-lg text-xs font-mono text-cyan-300 overflow-x-auto border border-slate-800">
                  {curlJson}
                </pre>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-slate-300">2. Raw HTML Body (`Content-Type: text/html`)</span>
                  <button
                    onClick={() => copyToClipboard(curlRaw, 2)}
                    className="text-xs text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1"
                  >
                    {copiedIndex === 2 ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedIndex === 2 ? 'Copy' : 'Copy cURL'}</span>
                  </button>
                </div>
                <pre className="bg-slate-950 p-3.5 rounded-lg text-xs font-mono text-cyan-300 overflow-x-auto border border-slate-800">
                  {curlRaw}
                </pre>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-slate-300">3. Render from Live URL (GET Request)</span>
                  <button
                    onClick={() => copyToClipboard(curlUrl, 3)}
                    className="text-xs text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1"
                  >
                    {copiedIndex === 3 ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedIndex === 3 ? 'Copy' : 'Copy cURL'}</span>
                  </button>
                </div>
                <pre className="bg-slate-950 p-3.5 rounded-lg text-xs font-mono text-cyan-300 overflow-x-auto border border-slate-800">
                  {curlUrl}
                </pre>
              </div>
            </div>
          </div>

          {/* Parameters Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h3 className="text-base font-bold text-white mb-4">रिक्वेस्ट पैरामीटर्स (Request Parameters)</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider bg-slate-950/40">
                    <th className="py-2.5 px-3 font-semibold">पैरामीटर (Key)</th>
                    <th className="py-2.5 px-3 font-semibold">टाइप</th>
                    <th className="py-2.5 px-3 font-semibold">डिफ़ॉल्ट</th>
                    <th className="py-2.5 px-3 font-semibold">विवरण</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  <tr>
                    <td className="py-2.5 px-3 font-mono text-cyan-300 font-semibold">html</td>
                    <td className="py-2.5 px-3 text-slate-400">string</td>
                    <td className="py-2.5 px-3 text-slate-500">-</td>
                    <td className="py-2.5 px-3">आपका पूरा HTML और इनलाइन/एक्सटर्नल CSS कोड।</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-mono text-cyan-300 font-semibold">url</td>
                    <td className="py-2.5 px-3 text-slate-400">string</td>
                    <td className="py-2.5 px-3 text-slate-500">-</td>
                    <td className="py-2.5 px-3">अगर HTML की जगह किसी वेब पेज की लिंक को PDF बनाना हो।</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-mono text-cyan-300 font-semibold">filename</td>
                    <td className="py-2.5 px-3 text-slate-400">string</td>
                    <td className="py-2.5 px-3 text-slate-500">"document.pdf"</td>
                    <td className="py-2.5 px-3">डाउनलोड होने वाली PDF का नाम (जैसे: Quotation_101.pdf)</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-mono text-cyan-300 font-semibold">format</td>
                    <td className="py-2.5 px-3 text-slate-400">string</td>
                    <td className="py-2.5 px-3 text-slate-500">"A4"</td>
                    <td className="py-2.5 px-3">पेज साइज: 'A4', 'Letter', 'Legal', 'A3', 'A5'</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-mono text-cyan-300 font-semibold">landscape</td>
                    <td className="py-2.5 px-3 text-slate-400">boolean</td>
                    <td className="py-2.5 px-3 text-slate-500">false</td>
                    <td className="py-2.5 px-3">अगर true हो तो लैंडस्केप ओरिएंटेशन में रेंडर होगा।</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-mono text-cyan-300 font-semibold">printBackground</td>
                    <td className="py-2.5 px-3 text-slate-400">boolean</td>
                    <td className="py-2.5 px-3 text-slate-500">true</td>
                    <td className="py-2.5 px-3">बैकग्राउंड रंग, इमेज और हेडर कलर्स को प्रिंट करने के लिए।</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-mono text-cyan-300 font-semibold">download</td>
                    <td className="py-2.5 px-3 text-slate-400">boolean</td>
                    <td className="py-2.5 px-3 text-slate-500">false</td>
                    <td className="py-2.5 px-3">false = ब्राउज़र में inline खुलेगा, true = तुरंत डाउनलोड होगा।</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-mono text-cyan-300 font-semibold">delay</td>
                    <td className="py-2.5 px-3 text-slate-400">number</td>
                    <td className="py-2.5 px-3 text-slate-500">0</td>
                    <td className="py-2.5 px-3">अगर आपके पेज में कोई जावास्क्रिप्ट या चार्ट लोड होने में समय लेता है (ms में)।</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Security & Response info */}
        <div className="space-y-6">
          {/* Security & API Key */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Shield className="w-5 h-5 text-amber-400" />
              सुरक्षा एवं API Key (वैकल्पिक)
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              डिफ़ॉल्ट रूप से आपकी PHP स्क्रिप्ट बिना किसी टोकन के सीधे कॉल कर सकती है।
            </p>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              अगर आप चाहते हैं कि केवल आपका PHP सर्वर ही इसे एक्सेस कर सके और कोई अनजान व्यक्ति इसे यूज़ न करे, तो आप AI Studio सेटिंग्स में <code className="text-amber-300">API_SECRET_KEY</code> एनवायरनमेंट वेरिएबल सेट कर सकते हैं।
            </p>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs font-mono text-slate-300 space-y-1">
              <div className="text-slate-500">// Header में पास करें:</div>
              <div className="text-cyan-400">X-Api-Key: your_secret_key</div>
              <div className="text-slate-500">// या Authorization में:</div>
              <div className="text-cyan-400">Authorization: Bearer your_secret_key</div>
            </div>
          </div>

          {/* Response Headers */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Globe className="w-5 h-5 text-cyan-400" />
              रिस्पांस हेडर (HTTP Headers)
            </h3>
            <div className="space-y-2 text-xs font-mono text-slate-300">
              <div className="flex justify-between border-b border-slate-800/80 py-1.5">
                <span className="text-slate-400">Content-Type</span>
                <span className="text-cyan-400">application/pdf</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 py-1.5">
                <span className="text-slate-400">Content-Disposition</span>
                <span className="text-cyan-400">inline; filename="..."</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 py-1.5">
                <span className="text-slate-400">X-Render-Time-Ms</span>
                <span className="text-emerald-400">240 (ms)</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-400">Access-Control-Allow-Origin</span>
                <span className="text-cyan-400">* (CORS enabled)</span>
              </div>
            </div>
          </div>

          {/* Tips for Best Quality */}
          <div className="bg-gradient-to-br from-slate-900 to-cyan-950/40 border border-cyan-800/40 rounded-xl p-6">
            <h3 className="text-sm font-bold text-cyan-300 mb-2">100% परफेक्ट रेंडरिंग टिप्स</h3>
            <ul className="text-xs text-slate-300 space-y-2 list-disc pl-4">
              <li>
                <strong>Page Size CSS:</strong> आप अपने CSS में <code>@page &#123; size: A4; margin: 0; &#125;</code> भी लिख सकते हैं, क्रोमियम इसे 100% फॉलो करेगा।
              </li>
              <li>
                <strong>Images:</strong> इमेजेस को या तो फुल URL (जैसे https://...) या फिर base64 डेटा URI (जैसे data:image/png;base64,...) के रूप में लगाएं।
              </li>
              <li>
                <strong>Page Break:</strong> नए पेज के लिए <code>page-break-before: always;</code> या <code>break-before: page;</code> का यूज़ करें।
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
