import { InvoiceTemplate } from '../types';

export const INVOICE_TEMPLATES: InvoiceTemplate[] = [
  {
    id: 'gst-invoice',
    name: 'GST Tax Invoice',
    nameHindi: 'जीएसटी टैक्स इनवॉइस',
    description: 'Multi-column GST invoice with CGST, SGST, HSN breakdown and bank details.',
    category: 'invoice',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tax Invoice - BillBilty</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #1e293b; background: #ffffff; padding: 24px; font-size: 13px; line-height: 1.4; }
    .invoice-card { max-width: 800px; margin: 0 auto; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; padding: 24px; background: #0f172a; color: #ffffff; }
    .company-title { font-size: 22px; font-weight: 700; color: #38bdf8; letter-spacing: -0.5px; }
    .company-sub { font-size: 12px; color: #94a3b8; margin-top: 4px; }
    .invoice-title { font-size: 20px; font-weight: 700; text-align: right; text-transform: uppercase; color: #ffffff; }
    .badge { display: inline-block; padding: 3px 8px; background: #0284c7; color: #ffffff; border-radius: 4px; font-size: 11px; font-weight: 600; margin-top: 6px; }
    
    .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; padding: 20px 24px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; }
    .meta-box h4 { font-size: 12px; text-transform: uppercase; color: #64748b; margin-bottom: 6px; letter-spacing: 0.5px; }
    .meta-box p { font-size: 13px; color: #1e293b; margin-bottom: 3px; }
    .meta-box strong { color: #0f172a; }

    table { width: 100%; border-collapse: collapse; }
    th { background: #f1f5f9; color: #475569; font-weight: 600; text-transform: uppercase; font-size: 11px; padding: 10px 12px; text-align: left; border-bottom: 1px solid #cbd5e1; }
    td { padding: 12px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: top; }
    tr:nth-child(even) { background-color: #fafafa; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }

    .summary-section { display: grid; grid-template-columns: 1.2fr 1fr; gap: 24px; padding: 20px 24px; border-top: 1px solid #e2e8f0; }
    .bank-details { background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 6px; padding: 14px; }
    .bank-title { font-weight: 700; color: #0f172a; margin-bottom: 6px; font-size: 12px; }
    
    .totals-table td { padding: 6px 0; border: none; font-size: 13px; }
    .grand-total { font-size: 16px; font-weight: 700; color: #0284c7; border-top: 2px solid #0284c7 !important; padding-top: 10px !important; }

    .footer { padding: 16px 24px; background: #f8fafc; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #64748b; }
    .signature-box { text-align: center; width: 180px; }
    .sig-line { border-bottom: 1px solid #94a3b8; margin-bottom: 6px; height: 35px; }
  </style>
</head>
<body>
  <div class="invoice-card">
    <div class="header">
      <div>
        <div class="company-title">BILLBILTY LOGISTICS &amp; TECH</div>
        <div class="company-sub">Plot 42, Transport Nagar, Jaipur, Rajasthan - 302001</div>
        <div class="company-sub">GSTIN: 08AAAAA0000A1Z5 | contact@billbilty.com</div>
      </div>
      <div style="text-align: right;">
        <div class="invoice-title">Tax Invoice</div>
        <div class="badge">ORIGINAL FOR RECIPIENT</div>
        <div style="font-size: 12px; color: #cbd5e1; margin-top: 6px;">Invoice #: <strong>BB-2026-8941</strong></div>
        <div style="font-size: 12px; color: #cbd5e1;">Date: <strong>20-Sep-2026</strong></div>
      </div>
    </div>

    <div class="meta-grid">
      <div class="meta-box">
        <h4>Billed To (Customer):</h4>
        <p><strong>Apex Industrial Enterprises Pvt Ltd</strong></p>
        <p>12-B, Industrial Area Phase 2, Gurgaon, Haryana - 122002</p>
        <p>GSTIN: 06ABCDE1234F1Z8 | State: Haryana (06)</p>
      </div>
      <div class="meta-box">
        <h4>Order &amp; Transport Info:</h4>
        <p>PO Number: <strong>PO-99214</strong></p>
        <p>Vehicle No: <strong>RJ-14-GA-7788</strong></p>
        <p>E-Way Bill: <strong>1411-9928-3310</strong></p>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th style="width: 40px;" class="text-center">#</th>
          <th>Item &amp; Description</th>
          <th class="text-center">HSN/SAC</th>
          <th class="text-center">Qty</th>
          <th class="text-right">Rate (₹)</th>
          <th class="text-center">GST %</th>
          <th class="text-right">Total (₹)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="text-center">1</td>
          <td>
            <strong>Heavy Duty Freight Transportation</strong><br>
            <span style="font-size: 11px; color: #64748b;">Jaipur Hub to Gurgaon Warehouse, 14-Wheeler Container</span>
          </td>
          <td class="text-center">996511</td>
          <td class="text-center">1 Trip</td>
          <td class="text-right">38,000.00</td>
          <td class="text-center">18%</td>
          <td class="text-right">38,000.00</td>
        </tr>
        <tr>
          <td class="text-center">2</td>
          <td>
            <strong>Loading &amp; Pallet Handling Charges</strong><br>
            <span style="font-size: 11px; color: #64748b;">Hydraulic crane loading for industrial machinery pallets</span>
          </td>
          <td class="text-center">996719</td>
          <td class="text-center">4 Pallets</td>
          <td class="text-right">1,750.00</td>
          <td class="text-center">18%</td>
          <td class="text-right">7,000.00</td>
        </tr>
        <tr>
          <td class="text-center">3</td>
          <td>
            <strong>Transit Cargo Insurance Fee</strong><br>
            <span style="font-size: 11px; color: #64748b;">Full value protection policy #IN-88910</span>
          </td>
          <td class="text-center">997133</td>
          <td class="text-center">1 Lot</td>
          <td class="text-right">2,500.00</td>
          <td class="text-center">18%</td>
          <td class="text-right">2,500.00</td>
        </tr>
      </tbody>
    </table>

    <div class="summary-section">
      <div class="bank-details">
        <div class="bank-title">BANK &amp; PAYMENT DETAILS:</div>
        <p style="font-size: 12px; margin-bottom: 2px;">Bank Name: <strong>HDFC Bank Ltd</strong></p>
        <p style="font-size: 12px; margin-bottom: 2px;">A/C Holder: <strong>BillBilty Technologies LLP</strong></p>
        <p style="font-size: 12px; margin-bottom: 2px;">A/C Number: <strong>50200088912345</strong></p>
        <p style="font-size: 12px; margin-bottom: 4px;">IFSC Code: <strong>HDFC0001234</strong></p>
        <p style="font-size: 11px; color: #64748b;">UPI ID: <strong>billbilty@hdfcbank</strong></p>
      </div>
      <div>
        <table class="totals-table">
          <tr>
            <td>Taxable Amount:</td>
            <td class="text-right">₹ 47,500.00</td>
          </tr>
          <tr>
            <td>IGST (18% Interstate):</td>
            <td class="text-right">₹ 8,550.00</td>
          </tr>
          <tr>
            <td>TCS / Round-off:</td>
            <td class="text-right">₹ 0.00</td>
          </tr>
          <tr class="grand-total">
            <td>Grand Total:</td>
            <td class="text-right">₹ 56,050.00</td>
          </tr>
        </table>
        <p style="font-size: 11px; color: #64748b; margin-top: 6px; text-align: right;">Amount in Words: <em>Fifty-Six Thousand Fifty Rupees Only</em></p>
      </div>
    </div>

    <div class="footer">
      <div>
        <p><strong>Terms:</strong> Payment due within 15 days of invoice date.</p>
        <p>Subject to Jaipur jurisdiction. This is a computer generated invoice.</p>
      </div>
      <div class="signature-box">
        <div class="sig-line"></div>
        <p><strong>For BillBilty Tech</strong><br><span style="font-size: 10px;">Authorized Signatory</span></p>
      </div>
    </div>
  </div>
</body>
</html>`
  },
  {
    id: 'quotation-modern',
    name: 'Modern Business Quotation',
    nameHindi: 'प्रोफेशनल कोटेशन / एस्टिमेट',
    description: 'Clean quotation layout with pricing breakdown, validity terms, and client proposal specs.',
    category: 'quotation',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Official Quotation</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif; color: #1e293b; background: #ffffff; padding: 32px; font-size: 13.5px; }
    .quote-wrapper { max-width: 820px; margin: 0 auto; }
    .header-bar { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #0284c7; padding-bottom: 20px; margin-bottom: 24px; }
    .brand-logo { font-size: 26px; font-weight: 800; color: #0f172a; }
    .brand-logo span { color: #0284c7; }
    .quote-tag { background: #e0f2fe; color: #0369a1; padding: 6px 14px; border-radius: 20px; font-weight: 700; font-size: 12px; letter-spacing: 0.5px; }

    .client-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px; }
    .box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; }
    .box-title { font-size: 11px; text-transform: uppercase; font-weight: 700; color: #64748b; margin-bottom: 8px; letter-spacing: 0.8px; }
    .box p { margin-bottom: 4px; color: #334155; }

    .items-table { width: 100%; border-collapse: separate; border-spacing: 0; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; margin-bottom: 24px; }
    .items-table th { background: #0f172a; color: #f8fafc; padding: 12px 14px; font-size: 11.5px; font-weight: 600; text-transform: uppercase; text-align: left; }
    .items-table td { padding: 14px; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
    .items-table tr:last-child td { border-bottom: none; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }

    .total-card { margin-left: auto; width: 320px; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; padding: 16px 20px; margin-bottom: 30px; }
    .total-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13.5px; }
    .total-highlight { border-top: 2px solid #0284c7; margin-top: 8px; padding-top: 10px; font-size: 17px; font-weight: 700; color: #0369a1; }

    .terms-box { background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 16px; margin-bottom: 30px; }
    .terms-title { font-weight: 700; color: #92400e; font-size: 12px; margin-bottom: 6px; }
    .terms-box ul { padding-left: 20px; font-size: 12px; color: #78350f; line-height: 1.6; }

    .signature-area { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; }
    .sig-person { text-align: center; width: 200px; }
    .sig-person .rule { border-bottom: 1px solid #94a3b8; height: 40px; margin-bottom: 6px; }
  </style>
</head>
<body>
  <div class="quote-wrapper">
    <div class="header-bar">
      <div>
        <div class="brand-logo">BILLBILTY<span>.COM</span></div>
        <p style="color: #64748b; font-size: 12px; margin-top: 3px;">Smart Billing &amp; Bilty Cloud Solutions</p>
      </div>
      <div style="text-align: right;">
        <span class="quote-tag">OFFICIAL QUOTATION</span>
        <p style="font-size: 12px; color: #64748b; margin-top: 8px;">Quote Ref: <strong>QT-2026-4402</strong></p>
        <p style="font-size: 12px; color: #64748b;">Issued: <strong>20 Sep 2026</strong> | Valid Until: <strong>05 Oct 2026</strong></p>
      </div>
    </div>

    <div class="client-grid">
      <div class="box">
        <div class="box-title">Quotation Prepared For</div>
        <p style="font-size: 14px; font-weight: 700; color: #0f172a;">Shree Ram Logistics &amp; Infra Ltd</p>
        <p>Transport Plaza, Ring Road, Ahmedabad, Gujarat</p>
        <p>Attn: Mr. Vikram Patel (Operations Director)</p>
        <p>Email: vikram.patel@shreeramlogistics.com</p>
      </div>
      <div class="box">
        <div class="box-title">Service Provider Details</div>
        <p style="font-size: 14px; font-weight: 700; color: #0f172a;">BillBilty Cloud Software</p>
        <p>Tech Park, Malviya Nagar, Jaipur, Rajasthan</p>
        <p>Phone: +91 98765 43210</p>
        <p>Support: support@billbilty.com</p>
      </div>
    </div>

    <table class="items-table">
      <thead>
        <tr>
          <th style="width: 40px;" class="text-center">#</th>
          <th>Item / Service Description</th>
          <th class="text-center">Qty / Period</th>
          <th class="text-right">Unit Price (₹)</th>
          <th class="text-right">Total Amount (₹)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="text-center">1</td>
          <td>
            <strong>Enterprise Bilty &amp; Quotation Engine License</strong><br>
            <span style="font-size: 11.5px; color: #64748b;">Multi-branch software access, unlimited bilty generation, automated e-way integration</span>
          </td>
          <td class="text-center">12 Months</td>
          <td class="text-right">2,500.00 /mo</td>
          <td class="text-right">30,000.00</td>
        </tr>
        <tr>
          <td class="text-center">2</td>
          <td>
            <strong>Chromium High-Fidelity PDF Microservice Setup</strong><br>
            <span style="font-size: 11.5px; color: #64748b;">Dedicated rendering microservice on Cloud Run, zero server load on shared hosting</span>
          </td>
          <td class="text-center">1 Setup</td>
          <td class="text-right">8,000.00</td>
          <td class="text-right">8,000.00</td>
        </tr>
        <tr>
          <td class="text-center">3</td>
          <td>
            <strong>Custom Quotation &amp; Consignment Template Designing</strong><br>
            <span style="font-size: 11.5px; color: #64748b;">3 Custom branded print templates with barcode, terms, and auto tax breakdown</span>
          </td>
          <td class="text-center">3 Templates</td>
          <td class="text-right">1,500.00</td>
          <td class="text-right">4,500.00</td>
        </tr>
      </tbody>
    </table>

    <div class="total-card">
      <div class="total-row">
        <span>Subtotal:</span>
        <strong>₹ 42,500.00</strong>
      </div>
      <div class="total-row">
        <span>GST (18%):</span>
        <strong>₹ 7,650.00</strong>
      </div>
      <div class="total-row total-highlight">
        <span>Final Quote Amount:</span>
        <span>₹ 50,150.00</span>
      </div>
    </div>

    <div class="terms-box">
      <div class="terms-title">TERMS &amp; CONDITIONS OF QUOTATION:</div>
      <ul>
        <li>This quotation is valid for 15 days from the date of issue.</li>
        <li>50% advance along with confirmed Purchase Order, balance upon system go-live.</li>
        <li>Implementation timeline: 3-5 working days from receipt of advance and client branding assets.</li>
        <li>Free support and maintenance included for 60 days following deployment.</li>
      </ul>
    </div>

    <div class="signature-area">
      <div class="sig-person">
        <div class="rule"></div>
        <p><strong>Customer Acceptance</strong><br><span style="font-size: 11px; color: #64748b;">Authorized Signatory</span></p>
      </div>
      <div class="sig-person">
        <div class="rule"></div>
        <p><strong>For BillBilty Tech</strong><br><span style="font-size: 11px; color: #64748b;">Sales &amp; Solutions Lead</span></p>
      </div>
    </div>
  </div>
</body>
</html>`
  },
  {
    id: 'transport-bilty',
    name: 'Goods Consignment Note (Lorry Bilty)',
    nameHindi: 'ट्रांसपोर्ट लॉरी बिल्टी (Consignment Note)',
    description: 'Specialized Indian transport consignment note with Consignor, Consignee, Truck No, and Freight Details.',
    category: 'bilty',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transport Bilty - Consignment Note</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; color: #0f172a; background: #fff; padding: 20px; font-size: 12px; }
    .bilty-border { border: 2px solid #0f172a; border-radius: 4px; max-width: 820px; margin: 0 auto; overflow: hidden; }
    .top-header { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: #0f172a; color: #fff; }
    .trans-title { font-size: 20px; font-weight: 800; letter-spacing: 0.5px; }
    .trans-sub { font-size: 11px; color: #94a3b8; }
    .bilty-number { font-size: 18px; font-weight: 800; color: #38bdf8; text-align: right; }
    
    .grid-party { display: grid; grid-template-columns: 1fr 1fr; border-bottom: 1px solid #0f172a; }
    .party-cell { padding: 10px 14px; border-right: 1px solid #0f172a; }
    .party-cell:last-child { border-right: none; }
    .cell-label { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #475569; margin-bottom: 4px; }
    .cell-name { font-size: 13px; font-weight: 700; color: #0f172a; margin-bottom: 2px; }

    .vehicle-row { display: grid; grid-template-columns: repeat(4, 1fr); background: #f8fafc; border-bottom: 1px solid #0f172a; }
    .v-item { padding: 8px 12px; border-right: 1px solid #cbd5e1; }
    .v-item:last-child { border-right: none; }
    .v-label { font-size: 9.5px; text-transform: uppercase; color: #64748b; font-weight: 600; }
    .v-val { font-size: 12px; font-weight: 700; color: #0f172a; margin-top: 2px; }

    table.goods-table { width: 100%; border-collapse: collapse; }
    table.goods-table th { background: #e2e8f0; color: #1e293b; font-size: 10.5px; font-weight: 700; text-transform: uppercase; padding: 8px; border-bottom: 1px solid #0f172a; border-right: 1px solid #cbd5e1; text-align: left; }
    table.goods-table td { padding: 10px 8px; border-bottom: 1px solid #e2e8f0; border-right: 1px solid #cbd5e1; font-size: 11.5px; }
    table.goods-table tr td:last-child, table.goods-table tr th:last-child { border-right: none; }
    
    .bottom-split { display: grid; grid-template-columns: 1.3fr 1fr; border-top: 1px solid #0f172a; }
    .terms-pane { padding: 12px; border-right: 1px solid #0f172a; font-size: 10px; color: #475569; }
    .freight-pane { padding: 10px 14px; background: #fafafa; }
    .f-row { display: flex; justify-content: space-between; padding: 4px 0; font-size: 12px; }
    .f-total { border-top: 2px solid #0f172a; margin-top: 6px; padding-top: 6px; font-weight: 800; font-size: 14px; color: #0284c7; }

    .sign-row { display: flex; justify-content: space-between; padding: 14px 16px; border-top: 1px solid #0f172a; background: #fff; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
  </style>
</head>
<body>
  <div class="bilty-border">
    <div class="top-header">
      <div>
        <div class="trans-title">SHREE GANESH ROADWAYS CARRIERS</div>
        <div class="trans-sub">Fleet Owners, Transport Contractors &amp; Heavy Cargo Movers</div>
        <div class="trans-sub">Regd. Head Office: Transport Nagar, Kota, Rajasthan | GSTIN: 08AALPG7711B1Z9</div>
      </div>
      <div>
        <div style="font-size: 10px; color: #94a3b8; text-transform: uppercase;">CONSIGNMENT NOTE (BILTY)</div>
        <div class="bilty-number">BILTY #: SGR-9942</div>
        <div style="font-size: 11px; color: #cbd5e1;">Date: 20/09/2026</div>
      </div>
    </div>

    <div class="vehicle-row">
      <div class="v-item">
        <div class="v-label">Lorry / Truck No:</div>
        <div class="v-val">RJ-20-GB-4591</div>
      </div>
      <div class="v-item">
        <div class="v-label">Driver Name &amp; Mob:</div>
        <div class="v-val">Ramswaroop (+91 94140 XXXXX)</div>
      </div>
      <div class="v-item">
        <div class="v-label">From (Origin):</div>
        <div class="v-val">Kota (Rajasthan)</div>
      </div>
      <div class="v-item">
        <div class="v-label">To (Destination):</div>
        <div class="v-val">Pune (Maharashtra)</div>
      </div>
    </div>

    <div class="grid-party">
      <div class="party-cell">
        <div class="cell-label">Consignor (Shipper / Sender):</div>
        <div class="cell-name">M/s Kota Stone Minerals &amp; Tiles</div>
        <p>Plot 88, RIICO Stone Park, Kota - 324005</p>
        <p>GSTIN: 08BBPKS9922M1ZQ | Phone: 0744-2451234</p>
      </div>
      <div class="party-cell">
        <div class="cell-label">Consignee (Receiver):</div>
        <div class="cell-name">M/s Western Buildcon Infrastructure</div>
        <p>Gate 4, Hadapsar Industrial Estate, Pune - 411028</p>
        <p>GSTIN: 27AABCV1234A1ZP | Phone: 020-26881122</p>
      </div>
    </div>

    <table class="goods-table">
      <thead>
        <tr>
          <th style="width: 50px;" class="text-center">Pkgs</th>
          <th>Description of Goods (Said to Contain)</th>
          <th class="text-center">Actual Wt.</th>
          <th class="text-center">Charged Wt.</th>
          <th class="text-center">Rate / MT</th>
          <th class="text-right">Freight (₹)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="text-center"><strong>420 Bags</strong></td>
          <td>
            <strong>Polished Kota Natural Flooring Stones</strong><br>
            <span style="font-size: 10px; color: #64748b;">Size: 22" x 22", Export Grade Packing. E-Way Bill: 1812-4412-9901</span>
          </td>
          <td class="text-center">21,400 Kg</td>
          <td class="text-center">22.00 MT</td>
          <td class="text-center">₹ 2,400.00</td>
          <td class="text-right">52,800.00</td>
        </tr>
      </tbody>
    </table>

    <div class="bottom-split">
      <div class="terms-pane">
        <p><strong>NOTICE &amp; CONDITIONS:</strong></p>
        <p>1. Goods booked strictly at Owner's risk. Transporter is not liable for leakage, natural weather damage, or road accidents unless insured.</p>
        <p>2. Demurrage will be charged @ ₹ 1,500/day if delivery is not taken within 24 hours of arrival at destination.</p>
        <p>3. Subject to Kota jurisdiction only.</p>
      </div>
      <div class="freight-pane">
        <div class="f-row">
          <span>Basic Freight:</span>
          <strong>₹ 52,800.00</strong>
        </div>
        <div class="f-row">
          <span>Loading &amp; Hamali:</span>
          <strong>₹ 1,200.00</strong>
        </div>
        <div class="f-row">
          <span>Toll / Statistical Chg:</span>
          <strong>₹ 500.00</strong>
        </div>
        <div class="f-row">
          <span>Advance Paid:</span>
          <span style="color: #dc2626;">- ₹ 20,000.00</span>
        </div>
        <div class="f-row f-total">
          <span>TO PAY AT DESTINATION:</span>
          <span>₹ 34,500.00</span>
        </div>
      </div>
    </div>

    <div class="sign-row">
      <div style="font-size: 11px;">
        <p>Consignor's Signature / Stamp: _____________________</p>
      </div>
      <div style="text-align: right; font-size: 11px;">
        <p><strong>For Shree Ganesh Roadways Carriers</strong></p>
        <p style="margin-top: 24px; color: #64748b;">Booking Clerk / Manager</p>
      </div>
    </div>
  </div>
</body>
</html>`
  },
  {
    id: 'custom-blank',
    name: 'Custom User Template',
    nameHindi: 'कस्टम एचटीएमएल (अपना कोड पेस्ट करें)',
    description: 'Blank template where you can paste your raw PHP output or custom invoice HTML.',
    category: 'minimal',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Custom Invoice</title>
  <style>
    body { font-family: sans-serif; padding: 40px; color: #333; }
    h1 { color: #0284c7; }
    .box { border: 2px dashed #cbd5e1; padding: 20px; border-radius: 8px; margin-top: 20px; }
  </style>
</head>
<body>
  <h1>Your Core PHP Quotation / Invoice</h1>
  <p>Paste your HTML directly here or send it from your PHP backend via cURL!</p>
  <div class="box">
    <h3>Chromium Engine Features:</h3>
    <ul>
      <li>Exact CSS Grid, Flexbox, and modern CSS3 styles</li>
      <li>Custom Web Fonts & Google Fonts</li>
      <li>Pixel-perfect margins, padding, and page breaks</li>
    </ul>
  </div>
</body>
</html>`
  }
];
