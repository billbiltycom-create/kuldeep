export interface RenderPdfRequest {
  html?: string;
  url?: string;
  filename?: string;
  baseUrl?: string;
  format?: 'A4' | 'Letter' | 'Legal' | 'A3' | 'A5';
  landscape?: boolean;
  printBackground?: boolean;
  scale?: number;
  delay?: number;
  download?: boolean;
  margin?: {
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
  };
}

export interface EngineStatus {
  status: 'ready' | 'initializing' | 'error';
  engine: string;
  browserVersion: string;
  browserConnected: boolean;
  activePages: number;
  memoryRssMb: number;
  memoryHeapUsedMb: number;
  nodeVersion: string;
  platform: string;
  uptimeSeconds: number;
  timestamp: string;
  appUrl: string;
  authConfigured: boolean;
}

export interface InvoiceTemplate {
  id: string;
  name: string;
  nameHindi: string;
  description: string;
  category: 'quotation' | 'invoice' | 'bilty' | 'minimal';
  html: string;
}
