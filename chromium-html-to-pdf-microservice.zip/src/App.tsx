import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { StudioView } from './components/StudioView';
import { PhpIntegrationView } from './components/PhpIntegrationView';
import { ApiDocsView } from './components/ApiDocsView';
import { EngineStatusView } from './components/EngineStatusView';
import { EngineStatus } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'studio' | 'php' | 'docs' | 'status'>('studio');
  const [status, setStatus] = useState<EngineStatus | null>(null);
  const [isLoadingStatus, setIsLoadingStatus] = useState<boolean>(false);
  const [apiUrl, setApiUrl] = useState<string>('');

  const fetchStatus = async () => {
    setIsLoadingStatus(true);
    try {
      const res = await fetch('/api/status');
      if (res.ok) {
        const data: EngineStatus = await res.json();
        setStatus(data);
        if (data.appUrl) {
          setApiUrl(data.appUrl);
        } else {
          setApiUrl(window.location.origin);
        }
      }
    } catch (err) {
      console.error('Failed to fetch status:', err);
      setApiUrl(window.location.origin);
    } finally {
      setIsLoadingStatus(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    // Use window.location.origin as default if not set
    if (!apiUrl && typeof window !== 'undefined') {
      setApiUrl(window.location.origin);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        status={status}
        apiUrl={apiUrl || (typeof window !== 'undefined' ? window.location.origin : '')}
      />

      {/* Main Content Body */}
      <main className="flex-1">
        {activeTab === 'studio' && (
          <StudioView apiUrl={apiUrl || (typeof window !== 'undefined' ? window.location.origin : '')} />
        )}

        {activeTab === 'php' && (
          <PhpIntegrationView apiUrl={apiUrl || (typeof window !== 'undefined' ? window.location.origin : '')} />
        )}

        {activeTab === 'docs' && (
          <ApiDocsView apiUrl={apiUrl || (typeof window !== 'undefined' ? window.location.origin : '')} />
        )}

        {activeTab === 'status' && (
          <EngineStatusView
            status={status}
            onRefresh={fetchStatus}
            isLoading={isLoadingStatus}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">BillBilty Chromium PDF Microservice</span>
            <span>•</span>
            <span>Google Chrome &amp; Puppeteer Engine</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => setActiveTab('php')}
              className="hover:text-cyan-400 transition-colors"
            >
              PHP DomPDF विकल्प
            </button>
            <span>•</span>
            <button
              onClick={() => setActiveTab('docs')}
              className="hover:text-cyan-400 transition-colors"
            >
              cURL API
            </button>
            <span>•</span>
            <button
              onClick={() => setActiveTab('status')}
              className="hover:text-cyan-400 transition-colors"
            >
              सिस्टम हेल्थ
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
